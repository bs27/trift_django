let items = [];
function changebut(buttonele) {
    var productName = buttonele.closest(".container").querySelector(".info h1").innerHTML;
    if(buttonele.innerHTML != "Added to Cart"){
        items.push(productName);
        buttonele.innerHTML = "Added to Cart";
        buttonele.style.cssText = "background-color: #ffffff;"
    } else {
        const index = items.indexOf(productName);
        if (index > -1) {
            items.splice(index, 1);
        }
        buttonele.innerHTML = "$XX - Add to Cart";
        buttonele.style.cssText = "background-color: #6fae40;"
    }
}
function addtocart(){
    console.log(items);
    localStorage.setItem('items', JSON.stringify(items));
    location.href = "http://127.0.0.1:8000/welcome/payment";
}