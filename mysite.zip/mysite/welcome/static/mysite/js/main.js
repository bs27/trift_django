document.addEventListener("touchstart", function() {
    window.location.href ="http://127.0.0.1:8000/welcome/buysell";
});

document.addEventListener("keydown", function() {
    window.location.href = "http://127.0.0.1:8000/welcome/buysell";
});