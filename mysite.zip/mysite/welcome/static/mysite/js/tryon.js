window.onload = function() {
    var elem = document.getElementById("container");
    setTimeout(()=>{
        if (elem){
            elem.innerHTML = "<p class=\"typewriter\" style=\"margin-top: -95vh;text-align: center;\">The Clothes are Now Ready. <span data-text=\"Please Try them on!\"></span></p>";
        }
        document.body.style.backgroundColor  = "#7c9969";

        var span = document.querySelector(".typewriter span");
        var textArr = span.getAttribute("data-text").split(", "); 
        var maxTextIndex = textArr.length; 

        var sPerChar = 0.15; 
        var sBetweenWord = 1.5;
        var textIndex = 0; 

        typing(textIndex, textArr[textIndex]); 

        function typing(textIndex, text) {
            var charIndex = 0; 
            var maxCharIndex = text.length - 1; 
            
            var typeInterval = setInterval(function () {
                span.innerHTML += text[charIndex]; 
                if (charIndex == maxCharIndex) {
                    clearInterval(typeInterval);
                } else {
                    charIndex += 1; 
                }
            }, sPerChar * 1000); 
        }
    }, 5000);
};

