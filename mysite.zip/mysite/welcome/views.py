from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return render(request, 'index.html', {})


# Create your views here.
def buysell(request):
    return render(request, 'buysell.html', {})


def buy(request):
    return render(request, 'buy.html', {})


def sell(request):
    return render(request, 'sell.html', {})


def tryon(request):
    return render(request, 'tryon.html', {})


def payment(request):
    return render(request, 'payment.html', {})